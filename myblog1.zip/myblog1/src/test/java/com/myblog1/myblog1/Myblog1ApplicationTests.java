package com.myblog1.myblog1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myblog1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
